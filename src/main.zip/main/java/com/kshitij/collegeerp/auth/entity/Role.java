package com.kshitij.collegeerp.auth.entity;

public enum Role {
    ADMIN,
    STUDENT,
    FACULTY,
    HOD,
    ACCOUNTANT,
    EXAM_CELL,
    LIBRARIAN
}
